﻿namespace APIClientForEconomic.Models
{
    public class PaymentTerms
    {
        public int PaymentTermsNumber { get; set; }
    }
}
