﻿namespace APIClientForEconomic.Models
{
    public class CustomerGroup
    {
        public string CustomerGroupNumber { get; set; }
    }
}
