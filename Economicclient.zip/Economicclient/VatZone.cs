﻿namespace APIClientForEconomic.Models
{
    public class VatZone
    {
        public int VatZoneNumber { get; set; }
    }
}
